BOBY ELECTRIC AND PLUMBER WEBSITE
===================================

Files:
- index.html: complete mobile-friendly website (HTML, CSS and JavaScript in one file)

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Find: const WHATSAPP_NUMBER = "91XXXXXXXXXX";
3. Replace it with your WhatsApp number including country code, digits only.
   Example format for India: 91 followed by your 10-digit mobile number.
4. Replace the placeholder service area and working hours.
5. Edit "Ask for price" in the price section to show your real prices.
6. Replace the sample gallery tiles with real work photos if you wish.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Sign in or create a GitHub account.
2. Create a new public repository, for example: boby-electric-plumber.
3. Upload index.html to the top/root of the repository.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. The website link appears in Settings > Pages.
The free address typically looks like https://YOUR-USERNAME.github.io/REPOSITORY-NAME/

Important: Prices, service area, hours, and WhatsApp number are placeholders until you update them.
